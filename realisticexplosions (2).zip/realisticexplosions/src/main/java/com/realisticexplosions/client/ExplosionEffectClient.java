package com.realisticexplosions.client;

import com.realisticexplosions.particle.ExplosionParticles;
import com.realisticexplosions.sound.SoundRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ExplosionEffectClient {

    public static final List<ShockwaveRing> SHOCKWAVES = new ArrayList<>();
    public static float shakePower = 0;
    public static float shakeX = 0;
    public static float shakeY = 0;
    public static float flashAlpha = 0;

    private static final List<DelayedSound> DELAYED_SOUNDS = new ArrayList<>();
    private static final Random RNG = new Random();

    // Максимум частиц за один взрыв — защита от вылета
    private static final int MAX_FIRE  = 25;
    private static final int MAX_SMOKE = 40;
    private static final int MAX_DUST  = 50;
    private static final int MAX_SPARK = 30;

    public static void triggerEffect(Vec3 center, float power, float normalizedPower,
                                     float distToPlayer, int soundDelayTicks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        // Вспышка — намного мягче, видна только вблизи
        float flashStrength = Math.max(0, 1.0f - distToPlayer / 20.0f);
        flashAlpha = Math.min(0.55f, normalizedPower * flashStrength * 0.4f);

        // Тряска
        float shakeStr = normalizedPower * Math.max(0, 1.0f - distToPlayer / 32.0f);
        shakePower = Math.max(shakePower, shakeStr * 5.0f);

        // Ударная волна
        SHOCKWAVES.add(new ShockwaveRing(center, normalizedPower));

        // Частицы с жёстким лимитом
        spawnFX(mc, center, normalizedPower, power);

        // Звук с задержкой по расстоянию
        DELAYED_SOUNDS.add(new DelayedSound(center, normalizedPower, soundDelayTicks));
    }

    private static void spawnFX(Minecraft mc, Vec3 c, float np, float power) {
        // Лимит масштабируется с мощностью, но не превышает максимум
        int fire  = Math.min(MAX_FIRE,  (int)(15 * np));
        int smoke = Math.min(MAX_SMOKE, (int)(25 * np));
        int dust  = Math.min(MAX_DUST,  (int)(30 * np));
        int spark = Math.min(MAX_SPARK, (int)(20 * np));

        // --- ОГОНЬ ---
        for (int i = 0; i < fire; i++) {
            double ang  = RNG.nextDouble() * Math.PI * 2;
            double elev = (RNG.nextDouble() - 0.2) * Math.PI * 0.6;
            double spd  = (0.2 + RNG.nextDouble() * 0.4) * Math.min(np, 2.0f);
            mc.level.addParticle(ParticleTypes.FLAME,
                c.x + (RNG.nextDouble()-0.5) * power * 0.5,
                c.y + RNG.nextDouble() * power * 0.3,
                c.z + (RNG.nextDouble()-0.5) * power * 0.5,
                Math.cos(ang)*Math.cos(elev)*spd,
                Math.abs(Math.sin(elev)*spd) + 0.1,
                Math.sin(ang)*Math.cos(elev)*spd);
        }

        // --- ДЫМ (чёрный, поднимается) ---
        for (int i = 0; i < smoke; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double r   = RNG.nextDouble() * Math.min(power, 3.0f) * 0.7;
            double h   = RNG.nextDouble() * power * 0.4;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SMOKE.get(),
                c.x + Math.cos(ang)*r,
                c.y + h,
                c.z + Math.sin(ang)*r,
                (RNG.nextDouble()-0.5)*0.08,
                0.08 + RNG.nextDouble()*0.18*Math.min(np, 2.0f),
                (RNG.nextDouble()-0.5)*0.08);
        }

        // --- ПЫЛЬ (низко, горизонтально) ---
        for (int i = 0; i < dust; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double spd = (0.3 + RNG.nextDouble() * 0.7) * Math.min(np, 2.0f);
            mc.level.addParticle(ExplosionParticles.EXPLOSION_DUST.get(),
                c.x + (RNG.nextDouble()-0.5) * Math.min(power, 4.0f) * 0.4,
                c.y + RNG.nextDouble() * 0.8,
                c.z + (RNG.nextDouble()-0.5) * Math.min(power, 4.0f) * 0.4,
                Math.cos(ang)*spd,
                RNG.nextDouble()*0.25,
                Math.sin(ang)*spd);
        }

        // --- ИСКРЫ ---
        for (int i = 0; i < spark; i++) {
            double ang  = RNG.nextDouble() * Math.PI * 2;
            double elev = RNG.nextDouble() * Math.PI * 0.6;
            double spd  = (0.8 + RNG.nextDouble()*1.5) * Math.min(np, 2.0f);
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SPARK.get(),
                c.x, c.y + 0.5, c.z,
                Math.cos(ang)*Math.cos(elev)*spd,
                Math.sin(elev)*spd + 0.2,
                Math.sin(ang)*Math.cos(elev)*spd);
        }
    }

    public static void tick() {
        // Тряска
        if (shakePower > 0.01f) {
            shakeX = (float)(RNG.nextGaussian() * shakePower * 0.7);
            shakeY = (float)(RNG.nextGaussian() * shakePower * 0.4);
            shakePower *= 0.73f;
            if (shakePower < 0.01f) { shakePower = 0; shakeX = 0; shakeY = 0; }
        }

        // Вспышка
        if (flashAlpha > 0.005f) {
            flashAlpha *= 0.75f;
            if (flashAlpha < 0.005f) flashAlpha = 0;
        }

        // Ударные волны
        SHOCKWAVES.removeIf(r -> { r.tick(); return r.isDead(); });

        // Звуки
        Minecraft mc = Minecraft.getInstance();
        Iterator<DelayedSound> it = DELAYED_SOUNDS.iterator();
        while (it.hasNext()) {
            DelayedSound ds = it.next();
            if (--ds.ticksLeft <= 0) {
                playSound(mc, ds);
                it.remove();
            }
        }
    }

    private static void playSound(Minecraft mc, DelayedSound ds) {
        if (mc.level == null) return;

        // Выбор звука по мощности взрыва
        SoundEvent sound;
        float baseVolume;
        if (ds.normalizedPower < 0.6f) {
            sound = SoundRegistry.EXPLOSION_SMALL.get();
            baseVolume = 2.0f;
        } else if (ds.normalizedPower < 1.5f) {
            sound = SoundRegistry.EXPLOSION_MEDIUM.get();
            baseVolume = 4.0f;
        } else if (ds.normalizedPower < 3.0f) {
            sound = SoundRegistry.EXPLOSION_LARGE.get();
            baseVolume = 6.0f;
        } else {
            sound = SoundRegistry.EXPLOSION_HUGE.get();
            baseVolume = 8.0f;
        }

        // Громкость зависит от расстояния (вычисляем здесь для надёжности)
        // playLocalSound сам затухает по расстоянию через attenuation_distance
        // но мы дополнительно масштабируем volume
        float pitch = 0.9f + RNG.nextFloat() * 0.2f;

        mc.level.playLocalSound(
            ds.center.x, ds.center.y, ds.center.z,
            sound, SoundSource.BLOCKS,
            baseVolume, pitch, false
        );
    }

    // --- Вложенные классы ---

    public static class ShockwaveRing {
        public final Vec3 center;
        public final float maxRadius;
        private int age = 0;
        private static final int LIFETIME = 30;

        public ShockwaveRing(Vec3 center, float np) {
            this.center = center;
            this.maxRadius = 4.0f + 12.0f * Math.min(np, 3.0f);
        }
        public void tick() { age++; }
        public boolean isDead() { return age >= LIFETIME; }

        public float getPartialRadius(float p) {
            float t = ((float)age + p) / LIFETIME;
            return maxRadius * (float)Math.sqrt(Math.min(t, 1.0f));
        }
        public float getPartialAlpha(float p) {
            float t = ((float)age + p) / LIFETIME;
            float cl = Math.min(t, 1.0f);
            return (1 - cl) * (1 - cl);
        }
    }

    static class DelayedSound {
        final Vec3 center;
        final float normalizedPower;
        int ticksLeft;

        DelayedSound(Vec3 c, float np, int ticks) {
            center = c; normalizedPower = np; ticksLeft = ticks;
        }
    }
}
