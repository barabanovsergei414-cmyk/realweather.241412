package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionSparkParticle extends TextureSheetParticle {

    private ExplosionSparkParticle(ClientLevel level, double x, double y, double z,
                                    double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);
        this.rCol = 1.0f;
        this.gCol = 0.5f + (float)(random.nextDouble() * 0.4);
        this.bCol = 0.0f;
        this.alpha = 1.0f;
        // Дольше живут: 2-4 секунды
        this.lifetime = 40 + random.nextInt(40);
        this.quadSize = 0.06f + (float)(random.nextDouble() * 0.09);
        this.gravity = 0.08f;
        this.xd = vx; this.yd = vy; this.zd = vz;
    }

    @Override
    public void tick() {
        this.xo = this.x; this.yo = this.y; this.zo = this.z;
        this.xd *= 0.96f;
        this.zd *= 0.96f;
        // Цвет: белый → оранжевый → красный
        float life = 1.0f - (float)this.age / this.lifetime;
        this.alpha = life * life;
        this.rCol = 1.0f;
        this.gCol = life * 0.65f;
        this.bCol = life > 0.6f ? (life - 0.6f) * 0.4f : 0;
        this.move(this.xd, this.yd - this.gravity, this.zd);
        if (this.age++ >= this.lifetime) this.remove();
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        public Factory(SpriteSet sprites) { this.sprites = sprites; }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionSparkParticle p = new ExplosionSparkParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
