package com.realisticexplosions.network;

import com.realisticexplosions.RealisticExplosions;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class NetworkHandler {

    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(RealisticExplosions.MODID, "main"),
        () -> PROTOCOL_VERSION,
        PROTOCOL_VERSION::equals,
        PROTOCOL_VERSION::equals
    );

    private static int id = 0;

    public static void register() {
        CHANNEL.messageBuilder(PacketExplosionEffect.class, id++, NetworkDirection.PLAY_TO_CLIENT)
            .decoder(PacketExplosionEffect::decode)
            .encoder(PacketExplosionEffect::encode)
            .consumerMainThread(PacketExplosionEffect::handle)
            .add();
    }

    public static void sendToPlayer(PacketExplosionEffect packet, ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
}
