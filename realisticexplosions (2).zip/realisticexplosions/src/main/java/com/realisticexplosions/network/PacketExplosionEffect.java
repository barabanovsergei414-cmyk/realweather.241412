package com.realisticexplosions.network;

import com.realisticexplosions.client.ExplosionEffectClient;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class PacketExplosionEffect {

    private final Vec3 center;
    private final float power;
    private final float normalizedPower;
    private final float distanceToPlayer;
    private final int soundDelayTicks;

    public PacketExplosionEffect(Vec3 center, float power, float normalizedPower,
                                  float distanceToPlayer, int soundDelayTicks) {
        this.center = center;
        this.power = power;
        this.normalizedPower = normalizedPower;
        this.distanceToPlayer = distanceToPlayer;
        this.soundDelayTicks = soundDelayTicks;
    }

    public static PacketExplosionEffect decode(FriendlyByteBuf buf) {
        return new PacketExplosionEffect(
            new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble()),
            buf.readFloat(),
            buf.readFloat(),
            buf.readFloat(),
            buf.readInt()
        );
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeDouble(center.x);
        buf.writeDouble(center.y);
        buf.writeDouble(center.z);
        buf.writeFloat(power);
        buf.writeFloat(normalizedPower);
        buf.writeFloat(distanceToPlayer);
        buf.writeInt(soundDelayTicks);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ExplosionEffectClient.triggerEffect(center, power, normalizedPower,
                distanceToPlayer, soundDelayTicks);
        });
        ctx.get().setPacketHandled(true);
    }
}
